/**
 * 
 */
package SilvasGeorgeGabriel;
import java.util.*;
import java.time.LocalTime;
import java.util.Comparator;
/**
 * @author g.silvas
 *
 */
abstract public class Sfida
{
	//CAMPI CLASSE ASTRATTA CONDIVISI DA TUTTE LE SOTTOCLASSI 
	protected String id;
	protected String nomePrimoPartecipante;
	protected String nomeSecondoPartecipante;
	protected LocalTime oraSfida;
	//CAMPO ENUMERATIVO PER DIVERSIFICARE LE DIVERSE VALIDAZIONI
	public enum validation
	{
		CAMPIONATO,
		AMICHEVOLE;
	}
	public validation typeValidation;
	protected String descrizione;
	
	/**
	 * Metodo astratto per ottenere il valore del punteggio,
	 * trattandosi di sfide con punteggi differenti 
	 * questo va ridefinito per tutte tipologie di sfide 
	 * definite
	 * @return
	 * @throws IllegalArgumentException
	 */
	public abstract int evaluatePunteggio() throws IllegalArgumentException;
	
	/**Metodo per la ricerca di un nome tra le varie sfide inserite nell'array
	*e restituisce la prima sfida che soddisfa tale condizione
	*puntatore a NULL se non trova corrispondenza
	*/
	public static Sfida ricercaPartecipante(ArrayList<Sfida> elencoSfide,String nomeSearch) {
		for(Sfida s:elencoSfide) {
			if(s.nomePrimoPartecipante.equalsIgnoreCase(nomeSearch)||s.nomeSecondoPartecipante.equalsIgnoreCase(nomeSearch)) {
				return s;
			}
		}
		throw new NullPointerException("Error non � stato trovata alcuna sfida corrispondente");
	}
	
	//Metodo per ordinare per punteggio 
	public static void OrdinaPerPunteggio(ArrayList<Sfida> s) {
		Collections.sort(s,ComparatorByScore);
	}
	//Metodo per ordinare per tempo
	public static void OrdinaPerTempo(ArrayList<Sfida> s) {
		Collections.sort(s,ComparatorByTime);
	}
	
	/** 
	 *Implemento il metodo compare della classe comparator 
	 *cosi da poter creare pi� "parametri" di confronto
	 *(sia per il tempo della sfida che per il punteggio)
	 *in questo caso uno apposito per il punteggio 
	 *cosi da poterlo usare nella estensione della classe 
	 *collection per effettuare il sort del nostro array di sfide
	 */
	public static Comparator<Sfida> ComparatorByScore=new Comparator<Sfida>(){
		public int compare(Sfida s1,Sfida s2) {
			Integer xS1=s1.evaluatePunteggio();
			Integer xS2=s2.evaluatePunteggio();	
			return xS1.compareTo(xS2);		
		}
	};
	
	public static Comparator<Sfida> ComparatorByTime=new Comparator<Sfida>(){
		public int compare(Sfida s1,Sfida s2) {
			return s1.oraSfida.compareTo(s2.oraSfida);
		}
	};
	
	//OVERRIDING METODO TO STRING EREDITATO DA OBJECT
	public String toString() {
		return "| id = "+id +"|"+" Nome del primo partecipante = "+nomePrimoPartecipante+"|"+" Nome del secondo partecipante = "+nomeSecondoPartecipante+"|"+" L'ora a cui si terra la sfida = "+oraSfida+"|"+" Validazione sfida = "+typeValidation+"|"+" Descrizione della sfida = "+descrizione+"|";
	}
}
