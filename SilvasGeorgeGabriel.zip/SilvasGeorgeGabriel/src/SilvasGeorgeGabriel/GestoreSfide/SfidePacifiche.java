/**
 * 
 */
package SilvasGeorgeGabriel.GestoreSfide;
//sto importando il package contente la classe astratta sfida da implementare 
import SilvasGeorgeGabriel.Sfida;
import SilvasGeorgeGabriel.Sfida.validation; 
import java.time.*;
/**
 * @author g.silvas
 *
 */
public class SfidePacifiche extends Sfida {
	//VARIABILE statica o di classe per tenere
	//traccia CRESCENTE degli id utilizzati
	private static int autoGenerateIdforP=1; 
	
	public SfidePacifiche(String id,String nomePrimoPartecipante,String nomeSecondoPartecipante,LocalTime oraSfida,validation typeValidation,String descrizione) {
		this.id="P"+id;
		this.nomePrimoPartecipante=nomePrimoPartecipante;
		this.nomeSecondoPartecipante=nomeSecondoPartecipante;
		this.oraSfida=oraSfida;
		//da rivedere enumerativi
		this.typeValidation=typeValidation;
		this.descrizione=descrizione;
	}
	
	//Overloading interno in caso di mancato id all'inserimento
	//possibilit� fornita dalle istruzioni sul testo
	public SfidePacifiche(String nomePrimoPartecipante,String nomeSecondoPartecipante,LocalTime oraSfida,validation typeValidation,String descrizione) {
		this(String.valueOf(autoGenerateIdforP), nomePrimoPartecipante, nomeSecondoPartecipante, oraSfida, typeValidation, descrizione);
		autoGenerateIdforP++;
	}
	
	/**
	 * Implementazione del metodo astratto della superclasse
	 * in questo caso ho la necessit� di creare un oggetto
	 * Exception(superclass) (IllegalArgi... sottoclasse)
	 * per trattare l'eccezione di sbagliato inserimento della 
	 * validazione
	 */
	public int evaluatePunteggio() throws IllegalArgumentException {
		switch (this.typeValidation){
			case AMICHEVOLE: return 10;
			case CAMPIONATO: return 100;
			default: throw new IllegalArgumentException("Error validation parameter not in range (choose AMICHEVOLE or COMPETIZIONE)");
		}
	}
}
