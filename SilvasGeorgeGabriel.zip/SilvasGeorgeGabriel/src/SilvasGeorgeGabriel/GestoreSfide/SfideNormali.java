/**
 * 
 */
package SilvasGeorgeGabriel.GestoreSfide;
import SilvasGeorgeGabriel.Sfida;
import SilvasGeorgeGabriel.Sfida.validation; 
import java.time.*;
/**
 * @author g.silvas
 *
 */
public class SfideNormali extends Sfida{
	private static int autoGenerateIdforN=1;
	//CAMPI AGGIUNTIVI DELLA SOTTOCLASSE SFIDENORMALI
	String luogoSfida;
	
	public SfideNormali(String id,String nomePrimoPartecipante,String nomeSecondoPartecipante,LocalTime oraSfida,validation typeValidation,String descrizione,String luogoSfida) {
		this.id="N"+id;
		this.nomePrimoPartecipante=nomePrimoPartecipante;
		this.nomeSecondoPartecipante=nomeSecondoPartecipante;
		this.oraSfida=oraSfida;
		//da rivedere enumerativi
		this.typeValidation=typeValidation;
		this.descrizione=descrizione;
		this.luogoSfida=luogoSfida;
	}
	
	//Overloading interno in caso di mancato id all'inserimento
	//possibilit� fornita dalle istruzioni sul testo
	public SfideNormali(String nomePrimoPartecipante,String nomeSecondoPartecipante,LocalTime oraSfida,validation typeValidation,String descrizione,String luogoSfida) {
		this(String.valueOf(autoGenerateIdforN), nomePrimoPartecipante, nomeSecondoPartecipante, oraSfida, typeValidation, descrizione, luogoSfida);
		autoGenerateIdforN++;
	}
	
	//IMPLEMENTAZIONE del metodo astrattto (OBBLIGATORIO)
	//dichiarato nella superclasse
	public int evaluatePunteggio() {
		LocalTime checkTime=LocalTime.of(12, 00);
		if(oraSfida.isBefore(checkTime)) {
			return 200;
		}
		else return 300;
	}
	
	//OVERRIDING metodo toSTring ereditato dalla superclasse
	// astratta "Sfida"
	public String toString() {
		return super.toString()+" Luogo della sfida = "+luogoSfida+"|";
	}
}
