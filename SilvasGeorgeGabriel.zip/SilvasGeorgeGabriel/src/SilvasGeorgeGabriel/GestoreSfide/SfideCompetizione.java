/**
 * 
 */
package SilvasGeorgeGabriel.GestoreSfide;
import SilvasGeorgeGabriel.Sfida;
import SilvasGeorgeGabriel.Sfida.validation; 
import java.time.*;
/**
 * @author g.silvas
 *
 */
public class SfideCompetizione extends Sfida{
	
	private static int autoGenerateIdforC=1;
	//CAMPO AGGIUNTIVO DELLA SOTTOCLASSE SFIDECOMPETIZIONE 
	//CHE TIENE TRACCIA DEL PUNTEGGIO DA 1 a 10 dellla sfida
	int punteggioDelGioco;
	public SfideCompetizione(String id,String nomePrimoPartecipante,String nomeSecondoPartecipante,LocalTime oraSfida,validation typeValidation,String descrizione,int punteggioDelGioco) {
		this.id="C"+id;
		this.nomePrimoPartecipante=nomePrimoPartecipante;
		this.nomeSecondoPartecipante=nomeSecondoPartecipante;
		this.oraSfida=oraSfida;
		this.typeValidation=typeValidation;
		this.descrizione=descrizione;
		if(punteggioDelGioco>0&&punteggioDelGioco<=10)
			this.punteggioDelGioco=punteggioDelGioco; // manca controllo sul range!!!
		else throw new IllegalArgumentException("Error punteggioDelGioco parameter not in range (choose beetween 1-10)");
	}
	
	//Overloading interno in caso di mancato id all'inserimento
	//possibilit� fornita dalle istruzioni sul testo
	public SfideCompetizione(String nomePrimoPartecipante,String nomeSecondoPartecipante,LocalTime oraSfida,validation typeValidation,String descrizione,int punteggioDelGioco) {
		this(String.valueOf(autoGenerateIdforC),nomePrimoPartecipante, nomeSecondoPartecipante, oraSfida, typeValidation,descrizione, punteggioDelGioco);
		autoGenerateIdforC++;
	}
	
	//IMPLEMENTAZIONE del metodo astrattto (OBBLIGATORIO)
	//dichiarato nella superclasse
	public int evaluatePunteggio(){
		return 1000+this.punteggioDelGioco*500;
	}
	
	//OVERRIDING metodo toSTring ereditato dalla superclasse
	// astratta "Sfida"
	public String toString() {
		
		return super.toString()+" Punteggio sfida competizione = "+punteggioDelGioco+"|";
	}
}
