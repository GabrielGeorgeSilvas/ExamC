/**
 * 
 */
package SilvasGeorgeGabriel;
import SilvasGeorgeGabriel.Sfida.validation;
import SilvasGeorgeGabriel.GestoreSfide.*;

import java.io.*;
import java.util.*;
import java.time.*;
/**
 * @author g.silvas
 *
 */
public class Main {
	public static void main(String[] args) throws FileNotFoundException, IOException{
		/**
		 * L'idea per la lettura da file � di avere un file.txt 
		 * contente sulla stessa line una e una sola sfida
		 * i vari valori sono separati dal carattere speciale ";" 
		 * e ciascun valore � composto da una descrizione 
		 * del valore + il valore stesso e un separatore ":",
		 * ese (id : P1293) dove "id" rappresenta
		 * la descrizione e "P1293" rappresenta il valore da salvare.
		 * Questi separatori serviranno poi per poter 
		 * tramite switch case e il metodo split di String 
		 * di estrarre le informazioni che vogliamo utilizzare 
		 * faccio ci� non per mia comprensione ma pi� per un discorso 
		 * di chiarezza dei dati anche nel file.txt 
		 * per evitare righe e righe di valori senza senso 
		 * evito creazione del file stesso 
		 */
		/*
		//inizializzo i canali di comunicazione con il file "c://etc",leggo e salvo il valore della prima riga nella variabile line 
		BufferedReader reader = new BufferedReader(new FileReader("c://prova.txt"));
        String line = reader.readLine();
        
        //creo un'array list di sfide
        ArrayList<Sfida> s=new ArrayList <Sfida>();
        
        //Variabili ausiliarie per salvare i dati riguardanti ogni sfida
        String id,nomePrimoPartecipante,nomeSecondoPartecipante,descrizione,luogoSfida;
        LocalDate oraSfida;
        validation typeValidation;
        int punteggioDelGioco;
        
        //creo un array di stringhe per aiutarmi a suddividere i valori della variabili che andiamo ad estrarre 
        String[] suppFile;
        //ciclo while che percorre tutto il file.txt
        while(line!=null) {
        	
        	//per ogni riga il nostro array puntera 
        	//a una sequenza diversa di valori ,
        	//suddivisi dal carattere speciale  ";" 
        	suppFile=line.split(";");
        	
        	suppFileMorw=suppFile
        	switch (suppFile=suppFile.split)
        	String[] evaluateID=suppFile[0].split(":");
        	switch (evaluateID[1].charAt(0)) {
        		case 'P': SfidePacifiche=new SfidePacifiche(for())
        	}
        }
        */
        
        //PARTE CHE MOSTRA LA CORRETTA COMPILAZIONE DEL CODICE
        //PURTROPPO MANCANZA TEMPO NON SONO RIUSCITO A TERMINARE
        //LA LETTURA DA FILE 
		ArrayList<Sfida> s=new ArrayList <Sfida>();
		//variabili banali per testare 
		//il programma 
		LocalTime t=LocalTime.of(12,00);
		LocalTime y=LocalTime.of(11,00);
		validation v=validation.AMICHEVOLE;
		//creazione di almeno una Sfida per tipo
		SfidePacifiche p=new SfidePacifiche("1920","Gabriel","George",t,v,"Call of Duty");
		SfideCompetizione c=new SfideCompetizione("1340","Luca","Rossi",t,v,"Mario car",9);
		SfideNormali n=new SfideNormali("1920","Acqua","Neve",y,v,"Mario Bros","New York");
		//aggiunta delle sfide nell'arrayList
		s.add(p);
		s.add(c);
		s.add(n);
		//test dell'ordinamento per Tempo 
		Sfida.OrdinaPerTempo(s);
		for(Sfida singolo:s) {
			System.out.println(singolo.toString()+"\n");
		}
		//test dell'ordinamento per Punteggio
		Sfida.OrdinaPerPunteggio(s);
		for(Sfida singolo:s) {
			System.out.println(singolo.toString()+"\n");
		}
		//test della ricerca per nome con restituzione della
		//prima sfida corrispondente
		System.out.println((Sfida.ricercaPartecipante(s, "Gabriel")).toString());
		
	}
		
}
